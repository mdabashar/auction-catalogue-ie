"""
Historical Auction Catalogue IE — Flask Web Application
PDF processing runs in a background thread pool; the API is non-blocking.
"""

import os
import sys
import time
import uuid
import threading
import traceback
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, request, jsonify, send_from_directory, render_template

# ── paths anchored to THIS file (works regardless of cwd on Windows) ─────────
BASE_DIR   = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
OUTPUT_DIR = BASE_DIR / "static" / "outputs"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ── locate the auction_catalogue_ie package ───────────────────────────────────
_candidate_roots = [
    BASE_DIR.parent,
    BASE_DIR.parent.parent,
    BASE_DIR.parent / "historical_auction_catalogue_ie",
    BASE_DIR / "historical_auction_catalogue_ie",
]
for _root in _candidate_roots:
    if (_root / "auction_catalogue_ie").is_dir():
        sys.path.insert(0, str(_root))
        break

app = Flask(
    __name__,
    template_folder=str(BASE_DIR / "templates"),
    static_folder=str(BASE_DIR / "static"),
)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024

jobs: dict = {}
jobs_lock  = threading.Lock()
executor   = ThreadPoolExecutor(max_workers=4)

# ── Windows auto-detection ────────────────────────────────────────────────────
def _find_tesseract_windows():
    import glob
    candidates = [
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
        os.path.expandvars(r"%USERPROFILE%\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None

def _find_poppler_windows():
    import glob
    patterns = [
        r"C:\Program Files\poppler*\Library\bin",
        r"C:\Program Files\poppler*\bin",
        r"C:\poppler*\bin",
        r"C:\poppler*\Library\bin",
        os.path.expandvars(r"%USERPROFILE%\poppler*\bin"),
        os.path.expandvars(r"%USERPROFILE%\Downloads\poppler*\bin"),
        os.path.expandvars(r"%USERPROFILE%\Downloads\Release-*\poppler*\bin"),
    ]
    for pat in patterns:
        matches = glob.glob(pat)
        if matches:
            return matches[0]
    return None

# ── import pipeline ───────────────────────────────────────────────────────────
try:
    from auction_catalogue_ie.pipeline import run_pipeline
    from auction_catalogue_ie.config   import PipelineConfig
    PIPELINE_AVAILABLE = True
    PIPELINE_ERROR     = None
except Exception:
    PIPELINE_AVAILABLE = False
    PIPELINE_ERROR     = traceback.format_exc()


# ══════════════════════════════════════════════════════════════════════════════
# Background worker
# ══════════════════════════════════════════════════════════════════════════════
def _process_pdf(job_id: str, pdf_path: Path, config_overrides: dict) -> None:
    job_output_dir = OUTPUT_DIR / job_id
    job_output_dir.mkdir(parents=True, exist_ok=True)

    with jobs_lock:
        jobs[job_id]["status"]     = "processing"
        jobs[job_id]["started_at"] = time.time()

    try:
        if not PIPELINE_AVAILABLE:
            raise RuntimeError(
                "auction_catalogue_ie package could not be imported.\n"
                "Ensure the historical_auction_catalogue_ie folder sits next to auction_webapp/.\n\n"
                + (PIPELINE_ERROR or "")
            )

        tess_cmd = config_overrides.get("tesseract_cmd")
        pop_path = config_overrides.get("poppler_path")
        if sys.platform == "win32":
            tess_cmd = tess_cmd or _find_tesseract_windows()
            pop_path = pop_path or _find_poppler_windows()

        config = PipelineConfig(
            dpi=config_overrides.get("dpi", 300),
            output_dir=job_output_dir,
            save_page_images=False,
            save_row_snippets=False,
            low_confidence_threshold=config_overrides.get("low_confidence_threshold", 70.0),
            sensitive_terms=config_overrides.get("sensitive_terms", PipelineConfig().sensitive_terms),
            tesseract_cmd=tess_cmd,
            poppler_path=pop_path,
        )

        records = run_pipeline(str(pdf_path), config=config, enable_nlp=False)
        stats   = _compute_stats(records)

        with jobs_lock:
            jobs[job_id].update(status="done", finished_at=time.time(),
                                records=records, stats=stats, error=None)

    except Exception:
        with jobs_lock:
            jobs[job_id].update(status="error", finished_at=time.time(),
                                error=traceback.format_exc(), records=[], stats={})


def _compute_stats(records):
    if not records:
        return {}
    lot_records = [r for r in records if r.get("lot_number")]
    review_recs = [r for r in records if r.get("needs_review")]
    sensitive   = [r for r in records if r.get("sensitivity_flag")]
    front_pages = [r for r in records if r.get("page_type") == "front_page"]
    confs       = [r["ocr_confidence"] for r in lot_records if r.get("ocr_confidence") is not None]
    avg_conf    = round(sum(confs) / len(confs), 1) if confs else 0.0
    conf_bands  = {"<50": 0, "50-70": 0, "70-85": 0, "85-100": 0}
    for c in confs:
        if c < 50: conf_bands["<50"] += 1
        elif c < 70: conf_bands["50-70"] += 1
        elif c < 85: conf_bands["70-85"] += 1
        else: conf_bands["85-100"] += 1
    section_counts, term_counts, reason_counts = {}, {}, {}
    for r in lot_records:
        sec = r.get("section_heading") or "Uncategorised"
        section_counts[sec] = section_counts.get(sec, 0) + 1
    for r in sensitive:
        for t in (r.get("sensitivity_terms") or []):
            term_counts[t] = term_counts.get(t, 0) + 1
    for r in review_recs:
        for part in (r.get("review_reason") or "Unknown").split(";"):
            part = part.strip()
            if part: reason_counts[part] = reason_counts.get(part, 0) + 1
    fp = next((r for r in front_pages), {})
    return {
        "total_records": len(records), "total_lots": len(lot_records),
        "total_pages": max((r.get("page_number", 0) for r in records), default=0),
        "needs_review": len(review_recs), "sensitive_count": len(sensitive),
        "front_pages": len(front_pages), "avg_ocr_confidence": avg_conf,
        "conf_bands": conf_bands, "section_counts": section_counts,
        "term_counts": term_counts, "reason_counts": reason_counts,
        "auction_house": fp.get("auction_house"), "sale_number": fp.get("sale_number"),
        "sale_dates": fp.get("sale_dates"), "categories": fp.get("categories"),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Routes
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/diagnostics")
def diagnostics():
    import shutil as sh, subprocess
    tess_path = _find_tesseract_windows() if sys.platform == "win32" else sh.which("tesseract")
    pop_path  = _find_poppler_windows()   if sys.platform == "win32" else sh.which("pdfinfo")
    tess_ver  = None
    if tess_path and os.path.isfile(str(tess_path)):
        try:
            tess_ver = subprocess.check_output(
                [str(tess_path), "--version"], stderr=subprocess.STDOUT, timeout=5
            ).decode().splitlines()[0]
        except Exception:
            pass
    return jsonify({
        "platform": sys.platform, "python": sys.version,
        "pipeline_ok": PIPELINE_AVAILABLE, "pipeline_error": PIPELINE_ERROR,
        "package_paths": sys.path[:10],
        "tesseract_found": str(tess_path) if tess_path else None,
        "tesseract_version": tess_ver,
        "poppler_found": str(pop_path) if pop_path else None,
        "base_dir": str(BASE_DIR),
    })


@app.route("/api/upload", methods=["POST"])
def upload():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "No files provided"}), 400
    low_conf = float(request.form.get("low_confidence_threshold", 70.0))
    dpi      = int(request.form.get("dpi", 300))
    tess_cmd = request.form.get("tesseract_cmd") or None
    pop_path = request.form.get("poppler_path")  or None
    created  = []
    for f in files:
        if not f.filename: continue
        job_id    = str(uuid.uuid4())[:8]
        save_path = UPLOAD_DIR / f"{job_id}_{Path(f.filename).name}"
        f.save(save_path)
        with jobs_lock:
            jobs[job_id] = {
                "job_id": job_id, "filename": f.filename, "status": "queued",
                "created_at": time.time(), "started_at": None, "finished_at": None,
                "records": [], "stats": {}, "error": None,
            }
        executor.submit(_process_pdf, job_id, save_path, {
            "dpi": dpi, "low_confidence_threshold": low_conf,
            "tesseract_cmd": tess_cmd, "poppler_path": pop_path,
        })
        created.append({"job_id": job_id, "filename": f.filename})
    return jsonify({"jobs": created}), 202


@app.route("/api/jobs")
def list_jobs():
    with jobs_lock:
        return jsonify([
            {"job_id": j["job_id"], "filename": j["filename"], "status": j["status"],
             "created_at": j["created_at"], "started_at": j["started_at"],
             "finished_at": j["finished_at"], "error": j["error"],
             "total_lots": j["stats"].get("total_lots", 0) if j["stats"] else 0}
            for j in sorted(jobs.values(), key=lambda x: x["created_at"], reverse=True)
        ])


@app.route("/api/jobs/<job_id>")
def job_status(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job: return jsonify({"error": "Job not found"}), 404
    return jsonify({k: v for k, v in job.items() if k != "records"})


@app.route("/api/jobs/<job_id>/stats")
def job_stats(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job: return jsonify({"error": "Job not found"}), 404
    return jsonify(job.get("stats") or {})


@app.route("/api/jobs/<job_id>/records")
def job_records(job_id):
    page, per_page = int(request.args.get("page", 1)), int(request.args.get("per", 50))
    filt, search   = request.args.get("filter", "all"), request.args.get("q", "").lower()
    with jobs_lock:
        job = jobs.get(job_id)
    if not job: return jsonify({"error": "Job not found"}), 404
    recs = list(job.get("records") or [])
    if filt == "review":   recs = [r for r in recs if r.get("needs_review")]
    elif filt == "sensitive": recs = [r for r in recs if r.get("sensitivity_flag")]
    elif filt == "lots":   recs = [r for r in recs if r.get("lot_number")]
    if search:
        recs = [r for r in recs if
                search in (r.get("lot_description") or "").lower() or
                search in (r.get("lot_number")      or "").lower() or
                search in (r.get("section_heading") or "").lower()]
    total = len(recs); start = (page - 1) * per_page
    return jsonify({"total": total, "page": page, "per": per_page,
                    "records": recs[start: start + per_page]})


@app.route("/api/jobs/<job_id>/sensitivity")
def job_sensitivity(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job: return jsonify({"error": "Job not found"}), 404
    recs = job.get("records") or []
    flagged = [r for r in recs if r.get("sensitivity_flag")]
    return jsonify({"flagged_count": len(flagged),
                    "term_counts": (job.get("stats") or {}).get("term_counts", {}),
                    "records": flagged})


@app.route("/api/jobs/<job_id>/download/<fmt>")
def download(job_id, fmt):
    if fmt not in ("csv", "json"): return jsonify({"error": "Invalid format"}), 400
    path = OUTPUT_DIR / job_id / f"lots.{fmt}"
    if not path.exists(): return jsonify({"error": "File not ready"}), 404
    return send_from_directory(str(OUTPUT_DIR / job_id), f"lots.{fmt}", as_attachment=True)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8080)
    args = ap.parse_args()
    print(f"\n{'='*56}")
    print(f"  Auction Catalogue IE  →  http://localhost:{args.port}")
    print(f"  Diagnostics           →  http://localhost:{args.port}/api/diagnostics")
    print(f"{'='*56}")
    print(f"  Pipeline available : {PIPELINE_AVAILABLE}")
    if not PIPELINE_AVAILABLE:
        print("  !! Package not found — check /api/diagnostics")
    print(f"  Base dir           : {BASE_DIR}\n")
    app.run(host="0.0.0.0", port=args.port, debug=False, threaded=True)
