#!/bin/bash
# Auction Catalogue IE — Web App Launcher
set -e
PORT=${1:-7788}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Create required directories
mkdir -p "$SCRIPT_DIR/static/uploads" "$SCRIPT_DIR/static/outputs"

# Install Flask if needed
python3 -c "import flask" 2>/dev/null || pip install flask flask-cors

echo "Starting Auction Catalogue IE Web App on http://localhost:$PORT"
cd "$SCRIPT_DIR"
python3 app.py --port $PORT
