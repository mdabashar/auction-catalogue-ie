from auction_catalogue_ie.parsing import parse_lot_row


def test_parse_basic_lot():
    row = "246 A massive 4-armed Indian bronze idol on stand, with shrine"
    parsed = parse_lot_row(row)
    assert parsed["lot_number"] == "246"
    assert "bronze idol" in parsed["lot_description"]


def test_parse_suffix_lot():
    row = "201A Six pierced silver menu holders"
    parsed = parse_lot_row(row)
    assert parsed["lot_number"] == "201A"


def test_no_lot_number():
    assert parse_lot_row("WEAPONS, BRONZES, &c.") is None
