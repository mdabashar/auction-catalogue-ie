from auction_catalogue_ie.front_page_parser import is_front_page, parse_front_page, extract_dates


FRONT_TEXT = """
SALE No. 14459/60.
STEVENS’S AUCTION ROOMS LTD.
38 King Street, Covent Garden, W.C. 2.
Catalogue
SALE BY AUCTION AT ABOVE ROOMS ON
Tues., 30th April, & Wed., 1st May, 1929
European and Native Weapons and Curios, China, Pictures,
Books, Plate, Medals, Bronzes, etc.
Antique and Modern Furniture.
COMMENCING AT ONE O’CLOCK.
ON VIEW DAY PRIOR AND MORNING OF SALE TILL 12 NOON.
"""


def test_front_page_detection():
    assert is_front_page(FRONT_TEXT)


def test_front_page_extracts_core_metadata():
    parsed = parse_front_page(FRONT_TEXT)
    assert parsed["sale_number"] == "14459/60"
    assert parsed["auction_house"] == "STEVENS’S AUCTION ROOMS LTD."
    assert parsed["address"] == "38 King Street, Covent Garden, W.C. 2"
    assert parsed["sale_dates"] == ["1929-04-30", "1929-05-01"]
    assert "European and Native Weapons" in parsed["categories"]
    assert parsed["sale_start_time"] == "ONE O’CLOCK"


def test_handwritten_numeric_date_pattern():
    assert "1929-04-30" in extract_dates("Date 30/4/29")
