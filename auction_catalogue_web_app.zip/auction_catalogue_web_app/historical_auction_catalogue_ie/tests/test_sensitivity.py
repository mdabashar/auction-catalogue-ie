from auction_catalogue_ie.sensitivity import flag_sensitive_terms


def test_sensitive_terms():
    flag, terms = flag_sensitive_terms("A ceremonial native weapon", ["native", "ceremonial"])
    assert flag is True
    assert "native" in terms
