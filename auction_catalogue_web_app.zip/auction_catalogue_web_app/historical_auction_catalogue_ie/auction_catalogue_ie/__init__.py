"""Historical auction catalogue information extraction package."""

__version__ = "0.1.0"
