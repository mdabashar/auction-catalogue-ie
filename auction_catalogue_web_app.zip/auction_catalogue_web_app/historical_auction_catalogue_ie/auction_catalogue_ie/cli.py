import argparse
from pathlib import Path

from .config import PipelineConfig
from .pipeline import run_pipeline


def build_parser():
    parser = argparse.ArgumentParser(
        description="Tesseract-only information extraction for historical auction catalogues."
    )

    parser.add_argument("input_file", help="PDF or image catalogue file")
    parser.add_argument("--output", default="outputs", help="Output directory")
    parser.add_argument("--dpi", type=int, default=300, help="PDF rasterization DPI")
    parser.add_argument("--tesseract-cmd", default=None, help="Path to tesseract executable")
    parser.add_argument("--poppler-path", default=None, help="Path to Poppler bin directory")
    parser.add_argument("--min-lot-patterns", type=int, default=5)
    parser.add_argument("--low-confidence-threshold", type=float, default=70.0)
    parser.add_argument("--enable-nlp", action="store_true", help="Enable optional spaCy enrichment")
    parser.add_argument("--no-page-images", action="store_true")
    parser.add_argument("--no-row-snippets", action="store_true")

    return parser


def main():
    args = build_parser().parse_args()

    config = PipelineConfig(
        dpi=args.dpi,
        tesseract_cmd=args.tesseract_cmd,
        poppler_path=args.poppler_path,
        min_lot_patterns_for_listing=args.min_lot_patterns,
        low_confidence_threshold=args.low_confidence_threshold,
        save_page_images=not args.no_page_images,
        save_row_snippets=not args.no_row_snippets,
        output_dir=Path(args.output),
    )

    records = run_pipeline(
        input_file=args.input_file,
        config=config,
        enable_nlp=args.enable_nlp,
    )

    print(f"Done. Extracted {len(records)} row-level records.")
    print(f"Outputs written to: {Path(args.output).resolve()}")


if __name__ == "__main__":
    main()
