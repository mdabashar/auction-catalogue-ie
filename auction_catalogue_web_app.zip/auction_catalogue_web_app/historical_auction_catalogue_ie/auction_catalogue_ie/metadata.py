import re
from typing import Dict, Optional
from .config import PipelineConfig


def extract_metadata(text: str) -> Dict[str, str]:
    metadata: Dict[str, str] = {}

    sale_no = re.search(r"SALE\s+No\.?\s*([0-9/]+)", text, re.I)
    if sale_no:
        metadata["sale_number"] = sale_no.group(1).strip()

    auction_house = re.search(r"(STEVENS['’]S\s+AUCTION\s+ROOMS\s+LTD\.?)", text, re.I)
    if auction_house:
        metadata["auction_house"] = normalize_title(auction_house.group(1))

    date = re.search(
        r"((?:Mon|Tues|Wednes|Thurs|Fri|Satur|Sun)day\.?,?\s+"
        r"\d{1,2}(?:st|nd|rd|th)?\s+\w+\.?,?\s+\d{4})",
        text,
        re.I,
    )
    if date:
        metadata["sale_date"] = date.group(1).strip()

    upper = text.upper()
    if "FIRST DAY" in upper:
        metadata["sale_day"] = "First Day"
    elif "SECOND DAY" in upper:
        metadata["sale_day"] = "Second Day"

    return metadata


def update_running_metadata(old: Dict[str, str], new: Dict[str, str]) -> Dict[str, str]:
    merged = old.copy()
    for key, value in new.items():
        if value:
            merged[key] = value
    return merged


def detect_section_heading(text: str, config: PipelineConfig) -> Optional[str]:
    upper = text.upper()
    for pattern in config.section_heading_patterns:
        if pattern in upper:
            return pattern
    return None


def normalize_title(value: str) -> str:
    return " ".join(part.capitalize() for part in value.split())
