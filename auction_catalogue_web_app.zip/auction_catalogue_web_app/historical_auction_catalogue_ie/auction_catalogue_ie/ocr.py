import pytesseract
import pandas as pd


def configure_tesseract(tesseract_cmd: str | None = None) -> None:
    if tesseract_cmd:
        pytesseract.pytesseract.tesseract_cmd = tesseract_cmd


def tesseract_text(image, psm: int = 6, whitelist: str | None = None) -> str:
    config = f"--oem 1 --psm {psm}"
    if whitelist:
        config += f' -c tessedit_char_whitelist="{whitelist}"'
    return pytesseract.image_to_string(image, config=config)


def tesseract_text_with_confidence(image, psm: int = 6, whitelist: str | None = None):
    config = f"--oem 1 --psm {psm}"
    if whitelist:
        config += f' -c tessedit_char_whitelist="{whitelist}"'

    data = pytesseract.image_to_data(
        image,
        config=config,
        output_type=pytesseract.Output.DATAFRAME,
    )

    if data is None or len(data) == 0:
        return "", 0.0

    data = data.dropna(subset=["text"])
    data = data[data["text"].astype(str).str.strip() != ""]

    if len(data) == 0:
        return "", 0.0

    text = " ".join(data["text"].astype(str).tolist())
    conf_data = data[data["conf"] >= 0]
    confidence = float(conf_data["conf"].mean()) if len(conf_data) else 0.0

    return text.strip(), confidence
