from typing import List, Tuple


def flag_sensitive_terms(description: str, sensitive_terms: List[str]) -> Tuple[bool, List[str]]:
    desc = (description or "").lower()
    found = [term for term in sensitive_terms if term.lower() in desc]
    return bool(found), found
