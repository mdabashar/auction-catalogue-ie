from pathlib import Path
from typing import List, Dict
import cv2
from tqdm import tqdm

from .config import PipelineConfig
from .io import load_pages, pil_to_cv, save_pil_page
from .ocr import configure_tesseract, tesseract_text_with_confidence
from .preprocessing import preprocess_page
from .page_classifier import classify_page
from .metadata import extract_metadata, update_running_metadata, detect_section_heading
from .front_page_parser import parse_front_page
from .segmentation import detect_lot_rows
from .parsing import parse_lot_row, clean_ocr_text
from .sensitivity import flag_sensitive_terms
from .validation import validate_lot_sequence
from .export import export_records
from .nlp import extract_entities_spacy


def run_pipeline(
    input_file: str,
    config: PipelineConfig | None = None,
    enable_nlp: bool = False,
) -> List[Dict]:
    config = config or PipelineConfig()
    configure_tesseract(config.tesseract_cmd)

    input_path = Path(input_file)
    output_dir = Path(config.output_dir)
    page_dir = output_dir / "page_images"
    snippet_dir = output_dir / "row_snippets"
    page_dir.mkdir(parents=True, exist_ok=True)
    snippet_dir.mkdir(parents=True, exist_ok=True)

    catalogue_id = input_path.stem
    pages = load_pages(str(input_path), dpi=config.dpi, poppler_path=config.poppler_path)

    running_metadata: Dict[str, str] = {}
    current_section = None
    all_records: List[Dict] = []

    for page_number, pil_page in enumerate(tqdm(pages, desc="Processing pages"), start=1):
        page_image_path = page_dir / f"page_{page_number:04d}.png"
        if config.save_page_images:
            save_pil_page(pil_page, page_image_path)

        original = pil_to_cv(pil_page)
        enhanced = preprocess_page(original)
        from .ocr import tesseract_text

        rough_text = tesseract_text(enhanced, psm=6)
        rough_conf = 0.0

        page_type = classify_page(rough_text, config)

        metadata = extract_metadata(rough_text)

        if page_type == "front_page":
            front_metadata = parse_front_page(rough_text)
            if front_metadata.get("sale_dates"):
                front_metadata["sale_date"] = "; ".join(front_metadata["sale_dates"])
            metadata.update({k: v for k, v in front_metadata.items() if v})

            front_record = {
                "catalogue_id": catalogue_id,
                "source_file": str(input_path),
                "page_number": page_number,
                "page_type": "front_page",
                "auction_house": metadata.get("auction_house"),
                "sale_number": metadata.get("sale_number"),
                "sale_date": metadata.get("sale_date"),
                "sale_day": metadata.get("sale_day"),
                "section_heading": None,
                "lot_number": None,
                "lot_description": None,
                "extracted_entities": {},
                "sensitivity_flag": False,
                "sensitivity_terms": [],
                "ocr_confidence": rough_conf,
                "needs_review": bool(front_metadata.get("confidence_notes")),
                "review_reason": "; ".join(front_metadata.get("confidence_notes") or []),
                "bbox": None,
                "row_snippet": None,
                "address": front_metadata.get("address"),
                "sale_dates": "; ".join(front_metadata.get("sale_dates") or []),
                "sale_date_text": front_metadata.get("sale_date_text"),
                "sale_start_time": front_metadata.get("sale_start_time"),
                "on_view_text": front_metadata.get("on_view_text"),
                "categories": front_metadata.get("categories"),
                "title": front_metadata.get("title"),
            }
            all_records.append(front_record)

        running_metadata = update_running_metadata(running_metadata, metadata)

        detected_heading = detect_section_heading(rough_text, config)
        if detected_heading:
            current_section = detected_heading

        if page_type not in {"lot_listing", "other", "sale_header"}:
            continue

        row_regions = detect_lot_rows(enhanced)
        page_records: List[Dict] = []

        for row_index, (x1, y1, x2, y2) in enumerate(row_regions, start=1):
            row_image = enhanced[y1:y2, x1:x2]

            snippet_path = snippet_dir / f"page_{page_number:04d}_row_{row_index:03d}.png"
            if config.save_row_snippets:
                cv2.imwrite(str(snippet_path), row_image)

            row_text, row_conf = tesseract_text_with_confidence(row_image, psm=6)
            row_text = clean_ocr_text(row_text)

            row_heading = detect_section_heading(row_text, config)
            if row_heading:
                current_section = row_heading
                continue

            parsed = parse_lot_row(row_text)

            base_record = {
                "catalogue_id": catalogue_id,
                "source_file": str(input_path),
                "page_number": page_number,
                "page_type": page_type,
                "auction_house": running_metadata.get("auction_house"),
                "sale_number": running_metadata.get("sale_number"),
                "sale_date": running_metadata.get("sale_date"),
                "sale_day": running_metadata.get("sale_day"),
                "section_heading": current_section,
                "ocr_confidence": row_conf,
                "bbox": [int(x1), int(y1), int(x2), int(y2)],
                "row_snippet": str(snippet_path) if config.save_row_snippets else None,
            }

            if parsed is None:
                record = {
                    **base_record,
                    "lot_number": None,
                    "lot_description": row_text,
                    "extracted_entities": {},
                    "sensitivity_flag": False,
                    "sensitivity_terms": [],
                    "needs_review": True,
                    "review_reason": "No lot number detected",
                }
                page_records.append(record)
                continue

            sensitivity_flag, terms = flag_sensitive_terms(
                parsed["lot_description"],
                config.sensitive_terms,
            )

            extracted_entities = (
                extract_entities_spacy(parsed["lot_description"])
                if enable_nlp else {}
            )

            needs_review = row_conf < config.low_confidence_threshold
            review_reason = "Low OCR confidence" if needs_review else ""

            record = {
                **base_record,
                "lot_number": parsed["lot_number"],
                "lot_description": parsed["lot_description"],
                "extracted_entities": extracted_entities,
                "sensitivity_flag": sensitivity_flag,
                "sensitivity_terms": terms,
                "needs_review": needs_review,
                "review_reason": review_reason,
            }
            page_records.append(record)

        page_records = validate_lot_sequence(page_records)
        all_records.extend(page_records)

    export_records(all_records, output_dir)
    return all_records
