import cv2
import numpy as np


def preprocess_page(image_bgr, deskew_enabled: bool = True):
    """
    Convert a catalogue page to a clean binary image and deskew it.

    The older implementation used cv2.minAreaRect over all foreground pixels.
    On catalogue pages with headings, borders, sparse text, or columns, that
    method often estimates the page *box* angle rather than the text-line angle.
    The result is under/over-rotation, which makes horizontal row projection join
    several lots into one diagonal snippet.

    This version estimates skew by trying small rotations and choosing the angle
    with the sharpest horizontal text-line projection.
    """
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (3, 3), 0)

    binary = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        35,
        15,
    )

    if deskew_enabled:
        binary = deskew(binary)

    return binary


def deskew(binary_image, max_angle: float = 15.0):
    """Deskew a black-text-on-white binary page using projection scoring."""
    inv = 255 - binary_image
    if int(np.count_nonzero(inv)) < 100:
        return binary_image

    # Use the central content band to reduce the influence of page borders and
    # very large headings. This is important for historical catalogue scans.
    ys, xs = np.where(inv > 0)
    if len(xs) == 0 or len(ys) == 0:
        return binary_image
    x1, x2 = np.percentile(xs, [2, 98]).astype(int)
    y1, y2 = np.percentile(ys, [2, 98]).astype(int)
    sample = binary_image[max(y1, 0):min(y2 + 1, binary_image.shape[0]),
                          max(x1, 0):min(x2 + 1, binary_image.shape[1])]

    angle = estimate_skew_angle(sample, max_angle=max_angle)
    if abs(angle) < 0.15:
        return binary_image

    return rotate_image(binary_image, angle, border_value=255)


def estimate_skew_angle(binary_image, max_angle: float = 15.0) -> float:
    """
    Return the rotation angle, in degrees, that makes text rows most horizontal.

    Positive return values are passed directly to cv2.getRotationMatrix2D.
    """
    # Coarse-to-fine search keeps this fast enough for a pipeline.
    coarse_angles = np.arange(-max_angle, max_angle + 0.001, 1.0)
    coarse_best = max(coarse_angles, key=lambda a: _horizontal_projection_score(binary_image, a))
    fine_angles = np.arange(coarse_best - 1.0, coarse_best + 1.0001, 0.1)
    fine_angles = fine_angles[(fine_angles >= -max_angle) & (fine_angles <= max_angle)]
    best = max(fine_angles, key=lambda a: _horizontal_projection_score(binary_image, a))
    return float(best)


def _horizontal_projection_score(binary_image, angle: float) -> float:
    rotated = rotate_image(binary_image, angle, border_value=255)
    inv = 255 - rotated

    # Light opening suppresses isolated speckles that otherwise add noise to the
    # projection profile.
    inv = cv2.morphologyEx(inv, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    projection = np.sum(inv > 0, axis=1).astype(np.float32)
    if projection.size < 3:
        return 0.0

    # Horizontal text has high peaks and deep valleys; the squared derivative of
    # the projection is a stable objective for old printed pages.
    return float(np.sum(np.diff(projection) ** 2))


def rotate_image(image, angle: float, border_value=255):
    h, w = image.shape[:2]
    center = (w / 2.0, h / 2.0)
    matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    cos = abs(matrix[0, 0])
    sin = abs(matrix[0, 1])
    new_w = int((h * sin) + (w * cos))
    new_h = int((h * cos) + (w * sin))
    matrix[0, 2] += (new_w / 2.0) - center[0]
    matrix[1, 2] += (new_h / 2.0) - center[1]
    return cv2.warpAffine(
        image,
        matrix,
        (new_w, new_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=border_value,
    )


def crop_content_area(binary_image, margin: int = 20):
    inv = 255 - binary_image
    ys, xs = np.where(inv > 0)

    if len(xs) == 0 or len(ys) == 0:
        return binary_image, (0, 0, binary_image.shape[1], binary_image.shape[0])

    x1 = max(int(xs.min()) - margin, 0)
    x2 = min(int(xs.max()) + margin, binary_image.shape[1])
    y1 = max(int(ys.min()) - margin, 0)
    y2 = min(int(ys.max()) + margin, binary_image.shape[0])

    return binary_image[y1:y2, x1:x2], (x1, y1, x2, y2)
