from dataclasses import dataclass, asdict
from typing import List, Optional


@dataclass
class BoundingBox:
    x1: int
    y1: int
    x2: int
    y2: int

    def as_list(self) -> List[int]:
        return [self.x1, self.y1, self.x2, self.y2]


@dataclass
class LotRecord:
    catalogue_id: str
    source_file: str
    page_number: int
    page_type: str
    auction_house: Optional[str] = None
    sale_number: Optional[str] = None
    sale_date: Optional[str] = None
    sale_day: Optional[str] = None
    section_heading: Optional[str] = None
    lot_number: Optional[str] = None
    lot_description: Optional[str] = None
    extracted_entities: Optional[dict] = None
    sensitivity_flag: bool = False
    sensitivity_terms: Optional[List[str]] = None
    ocr_confidence: float = 0.0
    needs_review: bool = False
    review_reason: str = ""
    bbox: Optional[List[int]] = None
    row_snippet: Optional[str] = None

    def to_dict(self):
        return asdict(self)
