from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


@dataclass
class PipelineConfig:
    dpi: int = 300
    tesseract_cmd: Optional[str] = None
    poppler_path: Optional[str] = None

    min_lot_patterns_for_listing: int = 2
    low_confidence_threshold: float = 70.0

    save_page_images: bool = True
    save_row_snippets: bool = True

    output_dir: Path = Path("outputs")

    sensitive_terms: List[str] = field(default_factory=lambda: [
        "native",
        "tribal",
        "indian",
        "aboriginal",
        "maori",
        "african",
        "egyptian",
        "human remains",
        "skull",
        "sacred",
        "ceremonial",
        "idol",
        "prayer wheel",
        "weapon",
        "war club",
        "fetish",
        "shrunken",
        "ancestral",
    ])

    section_heading_patterns: List[str] = field(default_factory=lambda: [
        "MISCELLANEOUS",
        "ORDERS, MEDALS",
        "WEAPONS, BRONZES",
        "OIL PAINTINGS",
        "ENGRAVINGS",
        "PRINTS",
        "BOOKS, MSS",
        "WATER-COLOURS",
        "CHINA",
        "ANOTHER PROPERTY",
    ])
