"""Front page detection and metadata extraction for historical auction catalogues.

The first page of many catalogues is not a lot-listing page. It often contains
sale number, auction-house name, address, printed sale dates, sale categories,
viewing instructions and start time. This module extracts those fields directly
so that the main pipeline does not silently skip title/front pages.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime
import re
from typing import Dict, List, Optional


MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

DAY_PREFIX_RE = r"(?:Mon(?:day)?|Tue(?:s|sday)?|Wed(?:nesday)?|Thu(?:rs|rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)\.?[,]?\s*"
ORDINAL_RE = r"(\d{1,2})(?:st|nd|rd|th)?"
MONTH_RE = r"([A-Za-z]{3,9})\.?"
YEAR_RE = r"(\d{4})"


@dataclass
class FrontPageRecord:
    page_type: str = "front_page"
    sale_number: Optional[str] = None
    auction_house: Optional[str] = None
    address: Optional[str] = None
    sale_dates: Optional[List[str]] = None
    sale_date_text: Optional[str] = None
    sale_start_time: Optional[str] = None
    on_view_text: Optional[str] = None
    categories: Optional[str] = None
    title: Optional[str] = None
    confidence_notes: Optional[List[str]] = None

    def to_dict(self) -> Dict:
        return asdict(self)


def normalise_space(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def normalise_title(text: str) -> str:
    text = normalise_space(text)
    return text.upper().replace("'", "’")


def is_front_page(text: str) -> bool:
    """Detect catalogue title/front pages using robust lexical signals."""
    low = (text or "").lower()
    if not low.strip():
        return False

    signals = [
        "sale no", "sale by auction", "auction rooms", "catalogue",
        "commencing at", "catalogues on application", "please bring this catalogue",
        "established", "telephone", "telegrams",
    ]
    score = sum(1 for s in signals if s in low)

    # Front pages sometimes OCR as "sale no" without lots. Lot pages usually
    # contain many numbered lot lines and fewer title-page signals.
    lot_lines = len(re.findall(r"(?m)^\s*\d{1,4}[A-Za-z]?\s+", text or ""))
    if score >= 3:
        return True
    if score >= 2 and lot_lines < 5:
        return True
    return False


def extract_sale_number(text: str) -> Optional[str]:
    m = re.search(r"sale\s*(?:no|number)\.?\s*[:#-]?\s*([0-9][0-9A-Za-z/.-]*)", text, re.I)
    return m.group(1).strip(" .,") if m else None


def extract_auction_house(text: str) -> Optional[str]:
    patterns = [
        r"((?:[A-Z][A-Z’'&.\-]+\s+){0,5}AUCTION\s+ROOMS\s+LTD\.?)",
        r"((?:[A-Z][A-Z’'&.\-]+\s+){0,5}AUCTIONEERS(?:\s+LTD\.?)?)",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I)
        if m:
            return normalise_title(m.group(1))
    return None


def extract_address(text: str) -> Optional[str]:
    """Extract an address line from the title page.

    OCR keeps title-page addresses as short standalone lines in most catalogues.
    We therefore first search line-by-line, then fall back to a paragraph regex.
    """
    street_words = r"(?:Street|St\.|Road|Rd\.|Lane|Square|Place|Avenue|Ave\.)"
    for raw_line in (text or "").splitlines():
        line = normalise_space(raw_line)
        if re.search(rf"\b\d{{1,4}}\s+.+\b{street_words}", line, re.I):
            return line.rstrip(" .")

    m = re.search(
        rf"(\d{{1,4}}\s+[A-Za-z0-9’'.,\-\s]+?{street_words}"
        rf"(?:[, ]+[A-Za-z0-9’'.,\-\s]+?)?(?:[A-Z]\.\s?[A-Z]\.\s?\d|London|\d{{4,5}})?\.?)",
        text,
        re.I,
    )
    return normalise_space(m.group(1)).rstrip(" .") if m else None


def _month_to_number(month: str) -> Optional[int]:
    return MONTHS.get(month.lower().rstrip("."))


def _date_to_iso(day: str, month: str, year: str) -> Optional[str]:
    month_no = _month_to_number(month)
    if not month_no:
        return None
    try:
        return datetime(int(year), month_no, int(day)).date().isoformat()
    except ValueError:
        return None


def extract_date_text(text: str) -> Optional[str]:
    patterns = [
        r"sale\s+by\s+auction.*?\bon\s+(.{0,140}?\d{4})",
        r"(?:on\s+)?(?:mon|tues?|wed|thurs?|fri|sat|sun)[a-z]*\.?[,]?.{0,120}?\d{4}",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I | re.S)
        if m:
            value = m.group(1) if m.lastindex else m.group(0)
            # Stop before category lines when possible.
            value = re.split(r"\n\s*(?:European|Antique|Curios|Pictures|Books|Plate|Medals|Bronzes)\b", value, flags=re.I)[0]
            return normalise_space(value).strip(" .")
    return None


def extract_dates(text: str) -> List[str]:
    """Extract printed and handwritten dates, including shared-year ranges.

    Handles examples such as:
    - Tues., 30th April, & Wed., 1st May, 1929
    - On TUESDAY, APRIL 30th, 1929
    - 30/4/29 handwritten margin dates
    """
    dates: List[str] = []

    # Numeric handwritten/receipt style: 30/4/29 or 30/04/1929
    for m in re.finditer(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b", text):
        d, mo, y = m.groups()
        year = int(y)
        if year < 100:
            year += 1900 if year >= 20 else 2000
        try:
            iso = datetime(year, int(mo), int(d)).date().isoformat()
            if iso not in dates:
                dates.append(iso)
        except ValueError:
            pass

    # Standard text dates with their own year: 1st May, 1929
    full_pat = re.compile(DAY_PREFIX_RE + r"?" + ORDINAL_RE + r"\s+" + MONTH_RE + r"[,]?\s*" + YEAR_RE, re.I)
    for m in full_pat.finditer(text):
        iso = _date_to_iso(m.group(1), m.group(2), m.group(3))
        if iso and iso not in dates:
            dates.append(iso)

    # Inverted text dates: APRIL 30th, 1929
    inv_pat = re.compile(r"\b" + MONTH_RE + r"\s+" + ORDINAL_RE + r"[,]?\s*" + YEAR_RE, re.I)
    for m in inv_pat.finditer(text):
        iso = _date_to_iso(m.group(2), m.group(1), m.group(3))
        if iso and iso not in dates:
            dates.append(iso)

    # Shared year: 30th April, & Wed., 1st May, 1929
    shared_pat = re.compile(
        ORDINAL_RE + r"\s+" + MONTH_RE + r"[,]?\s*(?:&|and|,)\s*" +
        r"(?:" + DAY_PREFIX_RE + r")?" + ORDINAL_RE + r"\s+" + MONTH_RE + r"[,]?\s*" + YEAR_RE,
        re.I,
    )
    for m in shared_pat.finditer(text):
        iso1 = _date_to_iso(m.group(1), m.group(2), m.group(5))
        iso2 = _date_to_iso(m.group(3), m.group(4), m.group(5))
        for iso in (iso1, iso2):
            if iso and iso not in dates:
                dates.append(iso)

    return sorted(dates)


def extract_start_time(text: str) -> Optional[str]:
    m = re.search(r"commencing\s+at\s+([^\n.]+(?:o[’']?clock|p\.?m\.?|a\.?m\.?)?)", text, re.I)
    if not m:
        m = re.search(r"at\s+(\d{1,2}\s*o[’']?clock\s*(?:precisely)?)", text, re.I)
    return normalise_space(m.group(1)).strip(" .") if m else None


def extract_on_view(text: str) -> Optional[str]:
    m = re.search(r"(on\s+view\s*[:\-]?.{0,180}?)(?:catalogues|telephone|please bring|$)", text, re.I | re.S)
    return normalise_space(m.group(1)).strip(" .") if m else None


def extract_categories(text: str) -> Optional[str]:
    # Capture the subject block between sale date and commencement.
    m = re.search(r"\d{4}\s+(.{0,350}?)\s+commencing\s+at", text, re.I | re.S)
    if not m:
        m = re.search(r"(?:catalogue\s+of|of)\s+(.{0,350}?)\s+commencing\s+at", text, re.I | re.S)
    if m:
        value = normalise_space(m.group(1))
        # Drop obvious OCR artifacts and keep meaningful catalogue subjects.
        value = re.sub(r"^[^A-Za-z]*(?:Catalogue\s+)?(?:of\s+)?", "", value, flags=re.I)
        return value.strip(" -.;") or None
    return None


def extract_title(text: str) -> Optional[str]:
    if re.search(r"\bcatalogue\b", text, re.I):
        return "Catalogue"
    return None


def parse_front_page(text: str) -> Dict:
    sale_dates = extract_dates(text)
    notes: List[str] = []
    if not sale_dates:
        notes.append("No sale date detected on front page")

    record = FrontPageRecord(
        sale_number=extract_sale_number(text),
        auction_house=extract_auction_house(text),
        address=extract_address(text),
        sale_dates=sale_dates,
        sale_date_text=extract_date_text(text),
        sale_start_time=extract_start_time(text),
        on_view_text=extract_on_view(text),
        categories=extract_categories(text),
        title=extract_title(text),
        confidence_notes=notes,
    )
    return record.to_dict()
