from typing import Dict, List


def extract_entities_spacy(text: str, model_name: str = "en_core_web_sm") -> Dict[str, List[str]]:
    """
    Optional enrichment. Requires:
      pip install spacy
      python -m spacy download en_core_web_sm
    """
    try:
        import spacy
    except ImportError:
        return {}

    try:
        nlp = spacy.load(model_name)
    except OSError:
        return {}

    doc = nlp(text or "")
    result: Dict[str, List[str]] = {}

    for ent in doc.ents:
        result.setdefault(ent.label_, [])
        if ent.text not in result[ent.label_]:
            result[ent.label_].append(ent.text)

    return result
