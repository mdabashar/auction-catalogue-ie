import re
from .config import PipelineConfig
from .front_page_parser import is_front_page


LOT_LINE_RE = re.compile(r"(?m)^\s*\d{1,4}[A-Za-z]?\s+")


def classify_page(text: str, config: PipelineConfig) -> str:
    low = text.lower()
    lot_patterns = LOT_LINE_RE.findall(text)

    condition_terms = ["conditions of sale", "highest bidder", "auctioneer", "purchaser"]
    sale_header_terms = ["first day's sale", "second day's sale", "at 1 o'clock", "on view"]

    if is_front_page(text):
        return "front_page"

    if len(lot_patterns) >= config.min_lot_patterns_for_listing:
        return "lot_listing"

    if sum(term in low for term in condition_terms) >= 2:
        return "conditions"

    if sum(term in low for term in sale_header_terms) >= 2:
        return "sale_header"

    if len(low.strip()) < 30:
        return "blank"

    return "other"
