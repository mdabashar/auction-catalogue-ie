from typing import List, Dict


def validate_lot_sequence(records: List[Dict]) -> List[Dict]:
    previous = None

    for record in records:
        lot = record.get("lot_number")

        if not lot:
            continue

        digits = "".join(ch for ch in str(lot) if ch.isdigit())
        if not digits:
            record["needs_review"] = True
            record["review_reason"] = append_reason(record.get("review_reason"), "Invalid lot number")
            continue

        current = int(digits)

        if previous is not None and current + 3 < previous:
            record["needs_review"] = True
            record["review_reason"] = append_reason(
                record.get("review_reason"),
                "Lot number sequence anomaly",
            )

        previous = current

    return records


def append_reason(existing: str | None, reason: str) -> str:
    if not existing:
        return reason
    if reason in existing:
        return existing
    return f"{existing}; {reason}"
