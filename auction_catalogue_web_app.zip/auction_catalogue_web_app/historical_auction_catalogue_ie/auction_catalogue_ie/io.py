from pathlib import Path
from typing import List
from PIL import Image
from pdf2image import convert_from_path
import cv2
import numpy as np


def load_pages(input_path: str, dpi: int = 300, poppler_path: str | None = None) -> List[Image.Image]:
    path = Path(input_path)
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        return convert_from_path(str(path), dpi=dpi, poppler_path=poppler_path)

    if suffix in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
        return [Image.open(path).convert("RGB")]

    raise ValueError(f"Unsupported input type: {suffix}")


def pil_to_cv(image: Image.Image) -> np.ndarray:
    return cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2BGR)


def save_pil_page(image: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)
