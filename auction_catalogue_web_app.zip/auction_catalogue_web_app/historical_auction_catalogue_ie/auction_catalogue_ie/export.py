from pathlib import Path
from typing import List, Dict
import pandas as pd


def export_records(records: List[Dict], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    df = pd.DataFrame(records)

    csv_path = output_dir / "lots.csv"
    json_path = output_dir / "lots.json"
    review_path = output_dir / "review_flags.csv"
    front_csv_path = output_dir / "front_pages.csv"
    front_json_path = output_dir / "front_pages.json"

    df.to_csv(csv_path, index=False)
    df.to_json(json_path, orient="records", indent=2, force_ascii=False)

    if "page_type" in df.columns:
        front_df = df[df["page_type"] == "front_page"].copy()
        front_df.to_csv(front_csv_path, index=False)
        front_df.to_json(front_json_path, orient="records", indent=2, force_ascii=False)
    else:
        pd.DataFrame().to_csv(front_csv_path, index=False)
        pd.DataFrame().to_json(front_json_path, orient="records", indent=2, force_ascii=False)

    if "needs_review" in df.columns:
        df[df["needs_review"] == True].to_csv(review_path, index=False)
    else:
        pd.DataFrame().to_csv(review_path, index=False)
