from typing import List, Tuple
import cv2
import numpy as np


BBox = Tuple[int, int, int, int]


def detect_lot_rows(binary_image) -> List[BBox]:
    """
    Detect lot-row regions from a deskewed binary page.

    This detector is intentionally conservative about merging: wrapped
    description lines are merged into the previous numbered lot, but any merged
    region that contains more than one left-column lot number is split again.
    The final re-splitting step fixes occasional historical catalogue pages
    where touching ascenders/descenders, tight leading, or residual skew make a
    horizontal projection join two or more adjacent lots into one row_snippet.
    """
    inv = 255 - binary_image
    h, w = inv.shape[:2]

    inv = cv2.morphologyEx(inv, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))

    # Restrict segmentation to printed content. Full-page projection is fragile
    # after deskewing because white triangles/margins can dominate the page.
    content_bbox = _content_bbox(inv, margin=12)
    cx1, cy1, cx2, cy2 = content_bbox
    content = inv[cy1:cy2, cx1:cx2]

    projection = np.sum(content > 0, axis=1)
    if projection.size == 0:
        return []

    nonzero = projection[projection > 0]
    threshold = max(4, int(np.percentile(nonzero, 20) * 0.6)) if len(nonzero) else 4
    has_text = projection > threshold

    raw_regions: List[BBox] = []
    start = None
    for y, active in enumerate(has_text):
        if active and start is None:
            start = y
        elif not active and start is not None:
            end = y
            if end - start > 4:
                raw_regions.append((cx1, cy1 + start, cx2, cy1 + end))
            start = None
    if start is not None:
        raw_regions.append((cx1, cy1 + start, cx2, cy2))

    raw_regions = merge_close_regions(raw_regions, max_gap=max(3, int(h * 0.002)))
    raw_regions = _split_unusually_tall_regions(inv, raw_regions)
    merged = merge_continuation_lines(inv, raw_regions)

    # Safety pass: if a merged row contains two or more genuine lot numbers in
    # the far-left number column, split it into one bbox per lot. This handles
    # cases like the attached examples where rows 177/178/179 or 180/181 were
    # saved as one snippet.
    return _split_regions_with_multiple_lot_numbers(inv, merged)


def merge_close_regions(regions: List[BBox], max_gap: int = 5) -> List[BBox]:
    if not regions:
        return []

    merged = [regions[0]]
    for x1, y1, x2, y2 in regions[1:]:
        px1, py1, px2, py2 = merged[-1]
        if y1 - py2 <= max_gap:
            merged[-1] = (min(px1, x1), py1, max(px2, x2), y2)
        else:
            merged.append((x1, y1, x2, y2))
    return merged


def merge_continuation_lines(inverted_image, regions: List[BBox]) -> List[BBox]:
    """
    Merge wrapped description lines into the previous numbered lot.

    A line starts a new row only when a compact digit-like component appears in
    the far-left lot-number column. Indented text in the description column is
    therefore treated as a continuation line.
    """
    merged: List[BBox] = []
    page_width = inverted_image.shape[1]
    lot_band_width = min(max(70, int(page_width * 0.10)), 170)

    for region in regions:
        x1, y1, x2, y2 = region
        crop = inverted_image[y1:y2, x1:x2]
        left_band = crop[:, :min(lot_band_width, crop.shape[1])]

        has_lot_number_candidate = _has_lot_number_blob(left_band)

        if has_lot_number_candidate or not merged:
            merged.append(_pad_bbox(region, inverted_image.shape, pad_x=8, pad_y=4))
        else:
            px1, py1, px2, py2 = merged[-1]
            merged[-1] = _pad_bbox((min(px1, x1), py1, max(px2, x2), y2), inverted_image.shape, pad_x=8, pad_y=4)

    return merged


def _split_regions_with_multiple_lot_numbers(inverted_image, regions: List[BBox]) -> List[BBox]:
    if not regions:
        return []

    output: List[BBox] = []
    page_width = inverted_image.shape[1]
    lot_band_width = min(max(70, int(page_width * 0.10)), 170)

    for region in regions:
        x1, y1, x2, y2 = region
        starts = _find_lot_number_starts(inverted_image, region, lot_band_width)
        if len(starts) <= 1:
            output.append(region)
            continue

        cuts = []
        crop = inverted_image[y1:y2, x1:x2]
        full_projection = np.sum(crop > 0, axis=1)

        for prev_start, next_start in zip(starts, starts[1:]):
            # Cut in the whitespace valley immediately before the next printed
            # lot number. Searching only after the previous number avoids
            # cutting inside wrapped description lines.
            search_top = max(prev_start + 4, next_start - max(10, int((next_start - prev_start) * 0.45)))
            search_bottom = max(search_top + 1, next_start - 1)
            local = full_projection[search_top:search_bottom]
            if local.size:
                rel = int(np.argmin(local))
                cut = y1 + search_top + rel
            else:
                cut = y1 + int((prev_start + next_start) / 2)
            cuts.append(cut)

        bounds = [y1] + cuts + [y2]
        for top, bottom in zip(bounds, bounds[1:]):
            if bottom - top > 6:
                output.append(_pad_bbox((x1, top, x2, bottom), inverted_image.shape, pad_x=0, pad_y=2))

    return output


def _find_lot_number_starts(inverted_image, region: BBox, lot_band_width: int) -> List[int]:
    """Return y offsets within region where a new left-column lot number starts."""
    x1, y1, x2, y2 = region
    crop = inverted_image[y1:y2, x1:x2]
    if crop.size == 0:
        return []

    left_band = crop[:, :min(lot_band_width, crop.shape[1])]
    if left_band.size == 0 or np.count_nonzero(left_band) < 10:
        return []

    band_h, band_w = left_band.shape[:2]
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats((left_band > 0).astype(np.uint8), 8)

    components = []
    for i in range(1, num_labels):
        x, y, w, h, area = stats[i]
        if area < 8:
            continue
        near_number_column = (x + w / 2.0) <= max(55, band_w * 0.45)
        compact_digit_like = (
            5 <= h <= band_h * 0.95
            and 2 <= w <= min(45, max(8, band_w * 0.35))
            and area <= max(350, h * w)
        )
        # Reject small punctuation and horizontal rules; keep digit-shaped blobs.
        aspect_ok = 0.08 <= (w / float(max(h, 1))) <= 1.35
        if near_number_column and compact_digit_like and aspect_ok:
            components.append((int(y), int(y + h), int(h)))

    if not components:
        return []

    components.sort()
    median_h = float(np.median([h for _, _, h in components]))
    cluster_gap = max(8, int(median_h * 0.75))

    clusters: List[List[Tuple[int, int, int]]] = []
    for comp in components:
        cy = (comp[0] + comp[1]) / 2.0
        if not clusters:
            clusters.append([comp])
            continue
        last = clusters[-1]
        last_cy = np.mean([(a + b) / 2.0 for a, b, _ in last])
        if abs(cy - last_cy) <= cluster_gap:
            last.append(comp)
        else:
            clusters.append([comp])

    starts = []
    for cluster in clusters:
        # A real lot number normally has two or three digit components. Allow a
        # single component for one-digit lots, but require enough ink to avoid
        # treating noise as a row start.
        top = min(c[0] for c in cluster)
        bottom = max(c[1] for c in cluster)
        ink_height = bottom - top
        if len(cluster) >= 2 or ink_height >= max(12, median_h * 0.8):
            starts.append(max(0, top - 2))

    # De-duplicate starts that are extremely close because broken digit pieces
    # can form two nearby clusters on degraded scans.
    deduped: List[int] = []
    for start in starts:
        if not deduped or start - deduped[-1] > max(10, int(median_h)):
            deduped.append(start)
    return deduped


def _has_lot_number_blob(left_band) -> bool:
    """Detect a printed lot number in the far-left number column."""
    return len(_find_lot_number_starts_from_band(left_band)) > 0


def _find_lot_number_starts_from_band(left_band) -> List[int]:
    if left_band.size == 0 or np.count_nonzero(left_band) < 10:
        return []

    band_h, band_w = left_band.shape[:2]
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats((left_band > 0).astype(np.uint8), 8)

    candidates = []
    for i in range(1, num_labels):
        x, y, w, h, area = stats[i]
        if area < 8:
            continue
        near_number_column = (x + w / 2.0) <= max(55, band_w * 0.45)
        compact_digit_like = (
            5 <= h <= band_h * 0.95
            and 2 <= w <= min(45, max(8, band_w * 0.35))
            and area <= max(350, h * w)
        )
        aspect_ok = 0.08 <= (w / float(max(h, 1))) <= 1.35
        if near_number_column and compact_digit_like and aspect_ok:
            candidates.append(int(y))
    return candidates


def _content_bbox(inv, margin: int = 12) -> BBox:
    ys, xs = np.where(inv > 0)
    if len(xs) == 0 or len(ys) == 0:
        return (0, 0, inv.shape[1], inv.shape[0])
    x1 = max(int(np.percentile(xs, 1)) - margin, 0)
    x2 = min(int(np.percentile(xs, 99)) + margin, inv.shape[1])
    y1 = max(int(np.percentile(ys, 1)) - margin, 0)
    y2 = min(int(np.percentile(ys, 99)) + margin, inv.shape[0])
    return (x1, y1, x2, y2)


def _split_unusually_tall_regions(inv, regions: List[BBox]) -> List[BBox]:
    if len(regions) < 3:
        return regions

    heights = np.array([y2 - y1 for _, y1, _, y2 in regions], dtype=np.float32)
    median_h = float(np.median(heights))
    if median_h <= 0:
        return regions

    output: List[BBox] = []
    for region in regions:
        x1, y1, x2, y2 = region
        if (y2 - y1) < median_h * 2.8:
            output.append(region)
            continue

        crop = inv[y1:y2, x1:x2]
        proj = np.sum(crop > 0, axis=1)
        valley = proj <= max(2, np.percentile(proj, 15))
        parts = []
        start = 0
        in_gap = False
        gap_start = None
        min_gap = max(3, int(median_h * 0.18))
        for idx, is_gap in enumerate(valley):
            if is_gap and not in_gap:
                in_gap = True
                gap_start = idx
            elif not is_gap and in_gap:
                if idx - gap_start >= min_gap:
                    if gap_start - start > 4:
                        parts.append((x1, y1 + start, x2, y1 + gap_start))
                    start = idx
                in_gap = False
        if y2 - (y1 + start) > 4:
            parts.append((x1, y1 + start, x2, y2))

        output.extend(parts if len(parts) > 1 else [region])
    return output


def _pad_bbox(bbox: BBox, image_shape, pad_x: int = 8, pad_y: int = 4) -> BBox:
    x1, y1, x2, y2 = bbox
    h, w = image_shape[:2]
    return (max(0, x1 - pad_x), max(0, y1 - pad_y), min(w, x2 + pad_x), min(h, y2 + pad_y))
