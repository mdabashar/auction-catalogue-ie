import re
from typing import Optional, Dict


LOT_RE = re.compile(r"^\s*(\d{1,4}[A-Za-z]?)\s+(.+)$")
SECTION_ONLY_RE = re.compile(r"^[A-Z][A-Z\s,&.\-]{4,}$")


def clean_ocr_text(text: str) -> str:
    text = text.replace("\n", " ")
    text = text.replace("—", "-")
    text = text.replace("–", "-")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def parse_lot_row(text: str) -> Optional[Dict[str, str]]:
    text = clean_ocr_text(text)

    if not text or SECTION_ONLY_RE.match(text):
        return None

    match = LOT_RE.match(text)
    if not match:
        return None

    lot_number = correct_lot_number(match.group(1))
    description = match.group(2).strip()

    return {
        "lot_number": lot_number,
        "lot_description": description,
    }


def correct_lot_number(value: str) -> str:
    """
    Conservative OCR correction for lot-number context only.
    """
    suffix = ""
    core = value

    if value and value[-1].isalpha():
        suffix = value[-1].upper()
        core = value[:-1]

    core = core.replace("O", "0").replace("o", "0").replace("l", "1").replace("I", "1")
    return core + suffix
