# Historical Auction Catalogue Information Extraction

A full Python package for extracting structured lot records from historical auction catalogues using **Tesseract only** for OCR.

The package is designed for catalogues like the attached Stevens's Auction Rooms example, which includes:
- front matter and sale metadata,
- conditions of sale,
- first/second day sale pages,
- section headings,
- multi-line lot descriptions,
- alphabetic lot suffixes such as `201A`,
- handwritten marginal annotations.

## System requirements

Install these system tools first:

### Tesseract

Windows:
```bash
winget install UB-Mannheim.TesseractOCR
```

Ubuntu/Debian:
```bash
sudo apt-get install tesseract-ocr
```

macOS:
```bash
brew install tesseract
```

### Poppler, needed by `pdf2image`

Windows:
Download Poppler and add its `bin` directory to PATH.

Ubuntu/Debian:
```bash
sudo apt-get install poppler-utils
```

macOS:
```bash
brew install poppler
```

## Install

From the package directory:

```bash
pip install -e .
```

## Run

```bash
auction-ie path/to/catalogue.pdf --output outputs --dpi 300
```

Or:

```bash
python -m auction_catalogue_ie.cli path/to/catalogue.pdf --output outputs --dpi 300
```

## Output

The pipeline writes:

```text
outputs/
  lots.csv
  lots.json
  front_pages.csv
  front_pages.json
  review_flags.csv
  page_images/
  row_snippets/
```

`front_pages.csv/json` contains title-page metadata such as auction house,
sale number, address, printed sale dates, sale date text, start time, viewing
text, and catalogue categories. Front-page rows are also included in `lots.csv`
with `page_type="front_page"` so downstream workflows can keep one combined
table if preferred.

## Optional NLP enrichment

Install spaCy and an English model:

```bash
pip install -e ".[nlp]"
python -m spacy download en_core_web_sm
```

Then run:

```bash
auction-ie catalogue.pdf --output outputs --enable-nlp
```

## Notes

This package intentionally uses only Tesseract for OCR. OpenCV is used for image preprocessing and segmentation only.
