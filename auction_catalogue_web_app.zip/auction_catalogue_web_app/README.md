# Auction Catalogue IE — Web App

## Quick Start

1. Make sure `tesseract-ocr` and `poppler-utils` are installed on your system.
2. Place this `webapp/` folder next to your `historical_auction_catalogue_ie/` package.
3. Run:

```bash
cd webapp
pip install flask
pip install -e ../historical_auction_catalogue_ie/
python app.py
```

4. Open http://localhost:5000 in your browser.

## Features

- **Drag-and-drop PDF upload** — drop any auction catalogue PDF
- **Live progress bar** via Server-Sent Events (SSE) — page-by-page updates
- **Background thread processing** — UI stays responsive during extraction
- **Stats dashboard** — totals, review flags, sensitive items
- **Downloadable outputs** — lots.csv, lots.json, front_pages.csv, review_flags.csv
- **Searchable records table** — filter by type, review status, or keyword
- **Paginated** — handles thousands of lot records

## Options

| Setting | Default | Description |
|---------|---------|-------------|
| DPI     | 200     | Higher = better OCR but slower |
| Save images | On | Saves page images and row snippets to disk |
