"""
Historical Auction Catalogue IE — Web App
Flask backend with background-thread processing and polling-based progress.
"""

import json
import logging
import os
import sys
import threading
import traceback
import uuid
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

PACKAGE_DIR = Path(__file__).parent.parent / "historical_auction_catalogue_ie"
if PACKAGE_DIR.exists():
    sys.path.insert(0, str(PACKAGE_DIR))

try:
    from auction_catalogue_ie.config import PipelineConfig
    from auction_catalogue_ie.io import load_pages, pil_to_cv, save_pil_page
    from auction_catalogue_ie.ocr import configure_tesseract, tesseract_text, tesseract_text_with_confidence
    from auction_catalogue_ie.preprocessing import preprocess_page
    from auction_catalogue_ie.page_classifier import classify_page
    from auction_catalogue_ie.metadata import extract_metadata, update_running_metadata, detect_section_heading
    from auction_catalogue_ie.front_page_parser import parse_front_page
    from auction_catalogue_ie.segmentation import detect_lot_rows
    from auction_catalogue_ie.parsing import parse_lot_row, clean_ocr_text
    from auction_catalogue_ie.sensitivity import flag_sensitive_terms
    from auction_catalogue_ie.validation import validate_lot_sequence
    from auction_catalogue_ie.export import export_records
    from auction_catalogue_ie.nlp import extract_entities_spacy
    import cv2
    PIPELINE_AVAILABLE = True
    log.info("Pipeline package loaded OK")
except ImportError as e:
    PIPELINE_AVAILABLE = False
    log.error("Pipeline import failed: %s", e)

BASE_DIR   = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024

JOBS: dict = {}
JOBS_LOCK  = threading.Lock()


def _update_job(job_id, **kwargs):
    with JOBS_LOCK:
        JOBS[job_id].update(kwargs)


def _run_job(job_id, input_path, config, enable_nlp):
    def progress(pct, msg):
        _update_job(job_id, percent=pct, message=msg)
        log.info("[%s] %d%% — %s", job_id[:8], pct, msg)

    try:
        if not PIPELINE_AVAILABLE:
            raise RuntimeError("Pipeline package not installed. Run: pip install -e historical_auction_catalogue_ie/")

        progress(2, "Configuring Tesseract…")
        configure_tesseract(config.tesseract_cmd)

        output_dir  = Path(config.output_dir)
        page_dir    = output_dir / "page_images"
        snippet_dir = output_dir / "row_snippets"
        page_dir.mkdir(parents=True, exist_ok=True)
        snippet_dir.mkdir(parents=True, exist_ok=True)
        catalogue_id = input_path.stem

        progress(5, f"Loading PDF at {config.dpi} DPI…")
        pages   = load_pages(str(input_path), dpi=config.dpi, poppler_path=config.poppler_path)
        n_pages = len(pages)
        progress(10, f"Loaded {n_pages} page(s). Starting OCR…")

        running_metadata = {}
        current_section  = None
        all_records      = []

        for page_number, pil_page in enumerate(pages, start=1):
            pct = 10 + int((page_number - 1) / n_pages * 85)
            progress(pct, f"OCR — page {page_number} of {n_pages}…")

            page_image_path = page_dir / f"page_{page_number:04d}.png"
            if config.save_page_images:
                save_pil_page(pil_page, page_image_path)

            original   = pil_to_cv(pil_page)
            enhanced   = preprocess_page(original)
            rough_text = tesseract_text(enhanced, psm=6)
            rough_conf = 0.0

            page_type = classify_page(rough_text, config)
            metadata  = extract_metadata(rough_text)

            if page_type == "front_page":
                front_metadata = parse_front_page(rough_text)
                if front_metadata.get("sale_dates"):
                    front_metadata["sale_date"] = "; ".join(front_metadata["sale_dates"])
                metadata.update({k: v for k, v in front_metadata.items() if v})
                all_records.append({
                    "catalogue_id": catalogue_id, "source_file": str(input_path),
                    "page_number": page_number, "page_type": "front_page",
                    "auction_house": metadata.get("auction_house"),
                    "sale_number": metadata.get("sale_number"),
                    "sale_date": metadata.get("sale_date"),
                    "sale_day": metadata.get("sale_day"),
                    "section_heading": None, "lot_number": None, "lot_description": None,
                    "extracted_entities": {}, "sensitivity_flag": False, "sensitivity_terms": [],
                    "ocr_confidence": rough_conf,
                    "needs_review": bool(front_metadata.get("confidence_notes")),
                    "review_reason": "; ".join(front_metadata.get("confidence_notes") or []),
                    "bbox": None, "row_snippet": None,
                    "address": front_metadata.get("address"),
                    "sale_dates": "; ".join(front_metadata.get("sale_dates") or []),
                    "sale_date_text": front_metadata.get("sale_date_text"),
                    "sale_start_time": front_metadata.get("sale_start_time"),
                    "on_view_text": front_metadata.get("on_view_text"),
                    "categories": front_metadata.get("categories"),
                    "title": front_metadata.get("title"),
                })

            running_metadata = update_running_metadata(running_metadata, metadata)
            detected_heading = detect_section_heading(rough_text, config)
            if detected_heading:
                current_section = detected_heading

            if page_type not in {"lot_listing", "other", "sale_header"}:
                continue

            row_regions  = detect_lot_rows(enhanced)
            page_records = []

            for row_index, (x1, y1, x2, y2) in enumerate(row_regions, start=1):
                row_image    = enhanced[y1:y2, x1:x2]
                snippet_path = snippet_dir / f"page_{page_number:04d}_row_{row_index:03d}.png"
                if config.save_row_snippets:
                    cv2.imwrite(str(snippet_path), row_image)

                row_text, row_conf = tesseract_text_with_confidence(row_image, psm=6)
                row_text = clean_ocr_text(row_text)

                row_heading = detect_section_heading(row_text, config)
                if row_heading:
                    current_section = row_heading
                    continue

                parsed = parse_lot_row(row_text)

                base = {
                    "catalogue_id": catalogue_id, "source_file": str(input_path),
                    "page_number": page_number, "page_type": page_type,
                    "auction_house": running_metadata.get("auction_house"),
                    "sale_number": running_metadata.get("sale_number"),
                    "sale_date": running_metadata.get("sale_date"),
                    "sale_day": running_metadata.get("sale_day"),
                    "section_heading": current_section,
                    "ocr_confidence": row_conf,
                    "bbox": [int(x1), int(y1), int(x2), int(y2)],
                    "row_snippet": str(snippet_path) if config.save_row_snippets else None,
                }

                if parsed is None:
                    page_records.append({**base,
                        "lot_number": None, "lot_description": row_text,
                        "extracted_entities": {}, "sensitivity_flag": False,
                        "sensitivity_terms": [], "needs_review": True,
                        "review_reason": "No lot number detected"})
                    continue

                flag, terms   = flag_sensitive_terms(parsed["lot_description"], config.sensitive_terms)
                entities      = extract_entities_spacy(parsed["lot_description"]) if enable_nlp else {}
                needs_review  = row_conf < config.low_confidence_threshold
                page_records.append({**base,
                    "lot_number": parsed["lot_number"],
                    "lot_description": parsed["lot_description"],
                    "extracted_entities": entities,
                    "sensitivity_flag": flag, "sensitivity_terms": terms,
                    "needs_review": needs_review,
                    "review_reason": "Low OCR confidence" if needs_review else ""})

            all_records.extend(validate_lot_sequence(page_records))

        progress(96, "Exporting CSV and JSON…")
        export_records(all_records, output_dir)

        stats = {
            "total":       len(all_records),
            "lots":        sum(1 for r in all_records if r.get("lot_number")),
            "front_pages": sum(1 for r in all_records if r.get("page_type") == "front_page"),
            "needs_review":sum(1 for r in all_records if r.get("needs_review")),
            "sensitive":   sum(1 for r in all_records if r.get("sensitivity_flag")),
        }
        _update_job(job_id, status="done", percent=100,
                    message="Extraction complete!", records=all_records, stats=stats)
        log.info("[%s] Done — %d records", job_id[:8], len(all_records))

    except Exception as exc:
        log.error("[%s] Pipeline error:\n%s", job_id[:8], traceback.format_exc())
        _update_job(job_id, status="error", message=str(exc), error=str(exc))


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    if "pdf" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    f = request.files["pdf"]
    if not f.filename.lower().endswith(".pdf"):
        return jsonify({"error": "Only PDF files are accepted"}), 400

    job_id = uuid.uuid4().hex
    (UPLOAD_DIR / job_id).mkdir(parents=True)
    (OUTPUT_DIR / job_id).mkdir(parents=True)
    input_path = UPLOAD_DIR / job_id / f.filename
    f.save(str(input_path))

    dpi         = int(request.form.get("dpi", 200))
    enable_nlp  = request.form.get("enable_nlp") == "true"
    save_images = request.form.get("save_images", "true") == "true"

    config = PipelineConfig(
        dpi=dpi, output_dir=OUTPUT_DIR / job_id,
        save_page_images=save_images, save_row_snippets=save_images,
    )

    with JOBS_LOCK:
        JOBS[job_id] = {
            "status": "running", "percent": 0, "message": "Queued…",
            "records": [], "stats": {}, "error": None,
            "output_dir": str(OUTPUT_DIR / job_id), "filename": f.filename,
        }

    threading.Thread(target=_run_job, args=(job_id, input_path, config, enable_nlp),
                     daemon=True, name=f"job-{job_id[:8]}").start()
    log.info("Started job %s for %s dpi=%d", job_id[:8], f.filename, dpi)
    return jsonify({"job_id": job_id})


@app.route("/poll/<job_id>")
def poll(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        return jsonify({"error": "Unknown job"}), 404
    return jsonify({
        "status":  job["status"],
        "percent": job["percent"],
        "message": job["message"],
        "stats":   job["stats"],
        "error":   job["error"],
    })


@app.route("/results/<job_id>")
def results(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        return jsonify({"error": "Unknown job"}), 404
    page     = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 50))
    records  = job.get("records", [])
    start    = (page - 1) * per_page
    return jsonify({"total": len(records), "page": page, "per_page": per_page,
                    "records": records[start: start + per_page]})


@app.route("/download/<job_id>/<filename>")
def download(job_id, filename):
    if filename not in {"lots.csv","lots.json","front_pages.csv","front_pages.json","review_flags.csv"}:
        return jsonify({"error": "File not permitted"}), 403
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        return jsonify({"error": "Unknown job"}), 404
    path = Path(job["output_dir"]) / filename
    if not path.exists():
        return jsonify({"error": "File not found"}), 404
    return send_file(str(path), as_attachment=True, download_name=filename)


@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "File too large (max 200 MB)"}), 413


@app.errorhandler(500)
def server_error(e):
    log.error("Unhandled 500: %s\n%s", e, traceback.format_exc())
    return jsonify({"error": "Internal server error — check server logs"}), 500


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5000, threaded=True)
